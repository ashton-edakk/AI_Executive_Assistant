// src/auth/dto/ensure-user.dto.ts
export class EnsureUserDto {
  id: string; // Supabase user ID
  email: string;
}
